
import { SessionService } from '../../core/services/session.service';
import { HttpService } from '../../core/services/http.service';
import { Injectable } from '@angular/core';
import { UserSigninInterface } from '../../interfaces/user-signin.interface';
import { HttpClient } from '@angular/common/http';

@Injectable({
  'providedIn': 'root'
})

export class SigninService {


  constructor(private http: HttpService<UserSigninInterface>, private session: SessionService){}
  
  // //Calls API with credentials and returns an Observable
  signin(email: any, password: any) {
    return this.http.post('user-signin', {'email': email, 'password': password});
  }

  // //Sets user session
  set setSignIn(user: any[]) {
   sessionStorage.setItem('user', JSON.stringify(user));
  }
  //
  // //Destroys user session
  signOut(): void {
    this.session.destroy();
  }


}


// import { SessionService } from '../../core/services/session.service';
// import { HttpService } from '../../core/services/http.service';
// import { Injectable } from '@angular/core';
// import { UserSigninInterface } from '../../interfaces/user-signin.interface';
// import { HttpClient } from '@angular/common/http';
//
// @Injectable({
//   'providedIn': 'root'
// })
//
// export class SigninService extends HttpService<UserSigninInterface> {
//
//
//   constructor(private http: HttpClient, private session: SessionService){
//     super(http);
//   }
//   //
//   // //Calls API with credentials and returns an Observable
//   // signin(email: any, password: any) {
//   //   return this.http.post('user-signin', {'email': email, 'password': password});
//   // }
//   //
//   // //Sets user session
//   set setSignIn(user: any[]) {
//    sessionStorage.setItem('user', JSON.stringify(user));
//   }
//   //
//   // //Destroys user session
//   // signOut(): void {
//   //   this.session.destroy();
//   // }
//
//
// }
