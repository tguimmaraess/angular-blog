import { Component, Injectable, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { SigninService } from './signin.service';
import { SessionService } from '../../core/services/session.service';
import { Validator } from '../../shared/common/helpers/validator';
import { Router } from '@angular/router';
//import { SnackBarComponent } from '../../shared/components/snack-bar/snack-bar.component';

@Component({
  selector: 'app-root',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})

export class SigninComponent {

  public title = 'Sign In';
  public userSignin: any;
  public email: string = '';
  public invalidSignin: boolean = false;
  public emailFormControl = this.validator.validateEmail()
  public passwordFormControl = this.validator.validatePassword()
  public matcher = this.validator.matcher()

  constructor(private validator: Validator,
              private formBuilder: FormBuilder,
              private signinService: SigninService,
              private router: Router,
            //  private snackBar: SnackBarComponent,
              private sessionService: SessionService) {}

  ngOnInit() {

    //If user is already signed in, redirects to te panel
    if(this.sessionService.isSignedIn) {
      this.router.navigate(['panel']);
    }

    //Form builder
    this.userSignin = this.formBuilder.group({
      email: this.emailFormControl,
      password: this.passwordFormControl
    })
  }


  //Gets response from sign in service
  doSignin(value: any): any {
    if(!this.userSignin.valid){
      return;
    } else {
      this.signinService.signin(value.email, value.password)
      .subscribe((response: any) => {
          if(response.message == 'ok') {
            this.signinService.setSignIn =  response.result;
            this.router.navigate(['panel']);
          //  this.snackBar.openSnackBar('Hello ' + response.result[0].name, 'success')
          } else {
          //  this.snackBar.openSnackBar(response.message, 'danger');
            this.invalidSignin = true;
          }
      });
    }
  }


  //
  // //Gets response from sign in service
  // doSignin(value: any): any {
  //   if(!this.userSignin.valid){
  //     return;
  //   } else {
  //     this.signinService.post('user-signin', value)
  //     .subscribe((response: any) => {
  //         if(response.message == 'ok') {
  //           this.signinService.setSignIn =  response.result;
  //           this.router.navigate(['panel']);
  //         //  this.snackBar.openSnackBar('Hello ' + response.result[0].name, 'success')
  //         } else {
  //         //  this.snackBar.openSnackBar(response.message, 'danger');
  //           this.invalidSignin = true;
  //         }
  //     });
  //   }
  // }

}
