import { Component, OnInit, ViewChild } from '@angular/core';
import { SettingsService } from './settings.service';
import { SessionService } from '../../core/services/session.service';
import { SnackBarService } from '../../shared/services/snack-bar.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Validator } from '../../shared/common/helpers/validator';
import { UserInterface } from '../../interfaces/user.interface';


@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})

export class SettingsComponent implements OnInit {

constructor(private service: SettingsService,
              private formBuilder: FormBuilder,
              private validator: Validator,
              private sessionService: SessionService,
              private snackBar: SnackBarService) { }



  public user: UserInterface = {} as UserInterface; //User interface
  public settingsForm: any = ''; //Form
  public message: string =  ''; //Message success or error
  public userId: number = this.sessionService.userId;
  public messageType: string =  ''; //Message type from bootstrap: success, warning, danger, info
  public emailFormControl =  this.validator.validateEmail(); //email validator

  ngOnInit(): void {
    this.getUserInformation();
    this.settingsForm =  this.formBuilder.group({
       email: null,
       id:   new FormControl(null, [Validators.required, Validators.min(1)]),
       name: new FormControl(null, [Validators.required])
    });
  }



  //Gets user details calling the getSettings function in SettingsService
  //Gets user details by caling and subscribing to the get function in HttpService extended by SettingsService
  //Passing the path and the param as function parameters
  getUserInformation() {
    this.service.getSettings().subscribe((response: any) => {
       this.user = response.result[0];
     });
  }

  //Upates user settings calling the updateSettings function in SettingsService
  updateSettings(value: any) {
    if(!this.settingsForm.valid) {
      return;
    }
    this.service.updateSettings(value).
    subscribe((response: any) => {
      if(response.message == 'ok') {
        this.snackBar.openSnackBar(this.message = 'Successfully updated', this.messageType = 'success');
      } else {
        this.snackBar.openSnackBar(this.message = 'Error saving settings', this.messageType = 'danger');
      }
    });
  }

}
