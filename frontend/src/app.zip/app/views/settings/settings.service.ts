import { SessionService } from '../../core/services/session.service';
import { HttpService } from '../../core/services/http.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { UserInterface } from '../../interfaces/user.interface';
import { HttpClient } from '@angular/common/http';

@Injectable({
  'providedIn': 'root'
})
export class SettingsService {

  constructor(private http: HttpService<UserInterface>, private sessionService: SessionService){}

  //Calls API with the user ID and returns an Observable
  getSettings() {
    return this.http.get('get-user', {'id': this.sessionService.userId});
  }

  //Posts to the API with credentials and returns an Observable ready to be subscribed
  updateSettings(parameters: any) {
    return this.http.post('update-user', parameters);
  }

}
