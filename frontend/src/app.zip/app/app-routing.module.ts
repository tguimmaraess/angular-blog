import { NgModule } from '@angular/core';
import { RouterModule, CanActivate, Routes } from '@angular/router';

//SigninGuard
import { SigninGuardService as SigninGuard } from './core/services/signin-guard.service';

// Component Imports
import { SigninComponent } from './views/signin/signin.component';
import { PanelComponent } from './views/panel/panel.component';
import { SettingsComponent } from './views/settings/settings.component';
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';

//Application Routes
const routes: Routes = [
  {
    path: '',
    component: SigninComponent //Signin Component
  },
  {
    path: '',
    component: MainLayoutComponent,  //Main Layout with children wich are the views.
    children:[                        //The children components will be loaded inside MainLayoutComponent
      {
          path: '',
          component: SigninComponent    //Sign in Component
      }, {
          path: 'panel',
          component: PanelComponent,   //Panel Component
          canActivate: [SigninGuard]
      }, {
          path: 'settings',
          component: SettingsComponent, //Settings Component
          canActivate: [SigninGuard]
        }
    ],
  },
  //Redirects to signin page if path is incorrect
  { path: '**', component: SigninComponent }, //Sign in Component

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
