/*
*@param   {string} resource     - Resource/endpoint (URL to be accessed) for post, put get and delete request.
*@param   {Object} parameters   - Parameters for post, put and delete request
*@param   {Object} [parameters] - Parameters for get request. This one is optional.
*@returns {Observable<T>}       - Observable containing the http response as well as the methods from Observable class
*/

//Angular Injectable to make possible the use of Injectable decorator
//which will allow us to use this class a anywhere within our aplication
import { Injectable } from '@angular/core';

/* Http Imports to communicate to the backend */
import { HttpClient, HttpErrorResponse } from '@angular/common/http'; //Http classes provided by Angular
import { Observable, throwError } from 'rxjs'; //Observable and throwError methods from rxjs
import { catchError, retryWhen, delay, take, map } from 'rxjs/operators'; //Handy functions that rxjs provides

//Service config such as base URL
import { URL_API } from './config/service.config';

//SnackBarService for displaying messages
import { SnackBarService } from '../../shared/services/snack-bar.service';


//Injectable decorator makes this class DI (Dependecy Injection), which means we can simply import this class in the
//classes we need to comunicate to the backend. We could make this class abstract but we would lose flexbility
//and it would be tightly coupled, which is not good. If any changes needs to be made,
//all the classes that implement this class would also have to be changed.
@Injectable({
  'providedIn': 'root'
})

/*
HttpService class will provide a way to comunicate to the backend services
A generic class that is type agnostic, meaning that it accepts a type that will be provided by the classes
that inject HttpService. A type is not required but important to fully take adavantage of TypeScript and Angular
This class will be injected in any classes that need to make HTTP requests
By doing that, we keep as DRY as possible (Don't Repeat Yourself).

This HttpService also uses pipe that allows to add handy functions to the HTTP request. Pipe is basically
the only function that can be chained to the request itself, we can, however, add functions inside the pipe method.
It's not mandatory but We do this to take advantage of separation of concerns and to better handle the errors,
especially as the project gets bigger these functions are really helpful as they will help us handling errors
without having to do it in the components services or even in components, when subscribing.

These requests use retryWhen and we have to keep a track of the counter manually but that's well worth it
as we have more control and all errors are handled here, in this class.
*/
export class HttpService<T> {

  constructor(private httpClient: HttpClient, private snackBar: SnackBarService){}

  private readonly _RetryAttempts = 3; //Number of attempts for a given resource if a HTTP request fails
  private readonly _DelayInSeconds = 3000 //Delay in seconds before trying again if a HTTP request fails

  //Posts to  API with parameters and returns an Observable
  post(resource: string, parameters: any): Observable<T> {
    return this.httpClient.post<T>(URL_API.url + resource, parameters)
    .pipe(
      retryWhen((errors) =>
        errors.pipe(
          delay(this._DelayInSeconds),
          take(this._RetryAttempts),
          map((error, i) => { //Map Function to loop throught the attempts
            let retries = 0; //Initializes retry variable with 0
            retries = retries + (i + 1); //Sum retries with index + 1 to get the actual value
            if(retries == this._RetryAttempts) { //Checks if all attempts were performed
              throw error; //Throws an error when the retries reach the max retry attempts
            }
            return error; //Returns the error
          })
        )
      ),
      catchError(this.handleError.bind(this)) //When the error is thrown, let's cacth it
    );
  }

  //Update an entity using Puts methods and returns an Observable
  updade(resource: string, parameters: any): Observable<T> {
    return this.httpClient.put<T>(URL_API.url +  resource, parameters)
    .pipe(
      retryWhen((errors) =>
        errors.pipe(
          delay(this._DelayInSeconds),
          take(this._RetryAttempts),
          map((error, i) => { //Map Function to loop throught the attempts
            let retries = 0; //Initializes retry variable with 0
            retries = retries + (i + 1); //Sum retries with index + 1 to get the actual value
            if(retries == this._RetryAttempts) { //Checks if all attempts were performed
              throw error; //Throws an error when the retries reach the max retry attempts
            }
            return error; //Returns the error
          })
        )
      ),
      catchError(this.handleError.bind(this)) //When the error is thrown, let's cacth it
    );
  }

  //Calls API with get request and returns an Observable
  get(resource: string, parameters?: any): Observable<T> {
    return this.httpClient.get<T>(URL_API.url + resource, { params: parameters })
    .pipe(
      retryWhen((errors) =>
        errors.pipe(
          delay(this._DelayInSeconds),
          take(this._RetryAttempts),
          map((error, i) => { //Map Function to loop throught the attempts
            let retries = 0; //Initializes retry variable with 0
            retries = retries + (i + 1); //Sum retries with index + 1 to get the actual value
            if(retries == this._RetryAttempts) { //Checks if all attempts were performed
              throw error; //Throws an error when the retries reach the max retry attempts
            }
            return error; //Returns the error
          })
        )
      ),
      catchError(this.handleError.bind(this)) //When the error is thrown, let's cacth it
    );
  }


  //Calls API with get request and returns an Observable. This method returns an array
  //and should be used to retrieve a list
  getMany(resource: string, parameters?: any): Observable<T[]> {
    return this.httpClient.get<T[]>(URL_API.url + resource, { params: parameters })
    .pipe(
      retryWhen((errors) =>
        errors.pipe(
          delay(this._DelayInSeconds),
          take(this._RetryAttempts),
          map((error, i) => { //Map Function to loop throught the attempts
            let retries = 0; //Initializes retry variable with 0
            retries = retries + (i + 1); //Sum retries with index + 1 to get the actual value
            if(retries == this._RetryAttempts) { //Checks if all attempts were performed
              throw error; //Throws an error when the retries reach the max retry attempts
            }
            return error; //Returns the error
          })
        )
      ),
      catchError(this.handleError.bind(this)) //When the error is thrown, let's cacth it
    );
  }

  //Delete request to the API and returns an Observable
  delete(resource: string, parameters: any)  {
    return this.httpClient.delete<T>(URL_API.url + resource, parameters)
    .pipe(
      retryWhen((errors) =>
        errors.pipe(
          delay(this._DelayInSeconds),
          take(this._RetryAttempts),
          map((error, i) => { //Map Function to loop throught the attempts
            let retries = 0; //Initializes retry variable with 0
            retries = retries + (i + 1); //Sum retries with index + 1 to get the actual value
            if(retries == this._RetryAttempts) { //Checks if all attempts were performed
              throw error; //Throws an error when the retries reach the max retry attempts
            }
            return error; //Returns the error
          })
        )
      ),
      catchError(this.handleError.bind(this)) //When the error is thrown, let's cacth it
    );
  }

  //Shows the error. The error handling is totally contained within this class
  private handleError(error: HttpErrorResponse) {
    this.snackBar.openSnackBar(error.statusText || 'We have an internal problem. We apologise.', 'danger');
    return throwError(error);
  }

}
