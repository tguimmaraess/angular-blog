import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { SessionService } from './session.service';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  'providedIn': 'root'
})

export class SigninGuardService implements CanActivate {

  constructor(private sessionService: SessionService, private router: Router){}

  //Method canActivate from CanActivate Interface protects all routes where this method is present
  //(Must be defined in src/app/app-routing.module.ts)
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean>{

    if(this.sessionService.signedInStatus) {
      return true;
    }

    if(this.sessionService.isSignedIn) {
      return true;
    } else  {
      this.router.navigate(['/']);
      return false;
    }

    // return this.signinService.isSignedIn.pipe(map(response => {
    //   alert(response)
    //     if(response) {
    //       this.signinService.setSignIn =  true;
    //       return true;
    //     } else {
    //       this.router.navigate(['/']);
    //       return false;
    //     }
    //   }))
  }

}
