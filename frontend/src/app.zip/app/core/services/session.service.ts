import { Injectable } from '@angular/core';
import { Router } from '@angular/router';


@Injectable({
  'providedIn': 'root'
})

export class SessionService {

  constructor(private router: Router){}

  //Private variable controls if the user is signed in or not
  private signedIn: boolean = false;

  //Gets signed in user id
  get userId(): number {
     return JSON.parse(sessionStorage.getItem('user') || '[]')[0]['id'];
  }

  //Gets signed in user email
  get userEmail(): string {
   return JSON.parse(sessionStorage.getItem('user') || '[]')[0]['email'];
  }

  //Gets signed in user name
  get userName(): string {
     return JSON.parse(sessionStorage.getItem('user') || '[]')[0]['name'];
  }

  //Gets user signed user status
  get signedInStatus() {
    return this.signedIn;
  }

  //Checks if user is signed in
  get isSignedIn(): string | null {
   return sessionStorage.getItem('user');
  }

  //Destroys user session
  destroy(): void {
    sessionStorage.clear();
    this.router.navigate(['/']);
  }


}
