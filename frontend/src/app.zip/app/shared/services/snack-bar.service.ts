import { Component, OnInit, Injectable, Input } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

//This service makes sure we have access to side nav functions
//even from  a different component other than Sienav itself
//Example: header component has a button to open and close the sidenav,
//even tho sidenav isn't in header component

@Injectable({
  'providedIn': 'root'
})
export class SnackBarService {

constructor(private snackBar: MatSnackBar) { }

openSnackBar(message: string, type: string) {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: [type]
    });
  }

}
