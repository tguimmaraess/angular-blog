import { Component } from '@angular/core';
import { SessionService } from '../../../core/services/session.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent{

  constructor(private session: SessionService) { }

  userName: string | null = '';

  ngOnInit(): void {
    this.userName = this.session.userName;
  }

  signOut() {
    this.session.destroy();
  }

}
