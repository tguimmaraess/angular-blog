export interface UserSigninInterface {
  id: number;
  email: string;
  name: string;
};
