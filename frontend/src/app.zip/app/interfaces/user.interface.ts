export interface UserInterface {
  email: string;
  name: string;
  password: string;  
};
