import { Component, OnInit, Injectable } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { SessionService } from '../../core/services/session.service';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.css']
})
@Injectable()
export class MainLayoutComponent {

  userEmail: string | null = '';

  constructor(private userDetails: SessionService){}


  ngOnInit() {
    this.userEmail = this.userDetails.userEmail;
  }

}
