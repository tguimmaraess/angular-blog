import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-without-menu',
  templateUrl: './layout-without-menu.component.html',
  styleUrls: ['./layout-without-menu.component.css']
})
export class LayoutWithoutMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
