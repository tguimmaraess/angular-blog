import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from './shared/shared.modules';

//Layouts
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';
import { LayoutWithoutMenuComponent } from './layouts/layout-without-menu/layout-without-menu.component';

//Views
import {SigninComponent } from './views/signin/signin.component';
import { PanelComponent } from './views/panel/panel.component';
import { SettingsComponent } from './views/settings/settings.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { SidenavComponent } from './shared/components/sidenav/sidenav.component';
import { SnackBarComponent } from './shared/components/snack-bar/snack-bar.component';

@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    SettingsComponent,
    PanelComponent,
    HeaderComponent,
    SidenavComponent,
    MainLayoutComponent,
    LayoutWithoutMenuComponent,
  //  SnackBarComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    SharedModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
